'use strict';
 
module.exports = {
  metadata: () => ({
    name: 'OkaComponent',
    properties: {
      variable: { required: true, type: 'string' },
      baseQuery: { required: true, type: 'string' },
      targetAudience: { required: true, type: 'string' }
    },
    supportedActions: ['success', 'failure']
  }),
    invoke: (conversation, done) => {

    const { variable } = conversation.properties();
    const { baseQuery } = conversation.properties();
    const { targetAudience } = conversation.properties();
    conversation.logger().info("Input parameter values: variable: "+variable+", baseQuery: "+baseQuery+", targetAudience: "+targetAudience);
    var tmpTargetCurrencies = targetCurrencies+","+baseCurrency;
    var fixerIoAPIKey = "<replace with your api key>"
    var reqUrl = "http://data.fixer.io/api/latest?access_key="+fixerIoAPIKey + "&base=EUR&symbols=" + tmpTargetCurrencies;
    // hide API key from logs
    conversation.logger().info("fixer.io request URL:"+reqUrl.replace(fixerIoAPIKey,"*********"));
    done();
  }
};
